const canvas = document.getElementById('pong');
const ctx = canvas.getContext('2d');

// Game objects
const paddleWidth = 10, paddleHeight = 80;
let leftY = canvas.height / 2 - paddleHeight / 2;
let rightY = canvas.height / 2 - paddleHeight / 2;
const ballSize = 10;
let ballX = canvas.width / 2 - ballSize / 2;
let ballY = canvas.height / 2 - ballSize / 2;
let ballSpeedX = 4, ballSpeedY = 4;
let leftScore = 0, rightScore = 0;

// Controls
const keys = {};
document.addEventListener('keydown', (e) => keys[e.key] = true);
document.addEventListener('keyup', (e) => keys[e.key] = false);

function drawRect(x, y, w, h, color) {
  ctx.fillStyle = color;
  ctx.fillRect(x, y, w, h);
}

function drawBall(x, y, size, color) {
  ctx.fillStyle = color;
  ctx.fillRect(x, y, size, size);
}

function drawText(text, x, y) {
  ctx.fillStyle = "#fff";
  ctx.font = "32px Arial";
  ctx.fillText(text, x, y);
}

function resetBall() {
  ballX = canvas.width / 2 - ballSize / 2;
  ballY = canvas.height / 2 - ballSize / 2;
  ballSpeedX = (Math.random() < 0.5 ? 4 : -4);
  ballSpeedY = (Math.random() < 0.5 ? 4 : -4);
}

function update() {
  // Paddle controls
  if (keys['w'] && leftY > 0) leftY -= 6;
  if (keys['s'] && leftY < canvas.height - paddleHeight) leftY += 6;
  if (keys['ArrowUp'] && rightY > 0) rightY -= 6;
  if (keys['ArrowDown'] && rightY < canvas.height - paddleHeight) rightY += 6;

  // Ball movement
  ballX += ballSpeedX;
  ballY += ballSpeedY;

  // Collision with top/bottom
  if (ballY < 0 || ballY > canvas.height - ballSize) ballSpeedY *= -1;

  // Collision with paddles
  if (
    ballX < paddleWidth &&
    ballY + ballSize > leftY &&
    ballY < leftY + paddleHeight
  ) {
    ballSpeedX *= -1;
    ballX = paddleWidth;
  }

  if (
    ballX + ballSize > canvas.width - paddleWidth &&
    ballY + ballSize > rightY &&
    ballY < rightY + paddleHeight
  ) {
    ballSpeedX *= -1;
    ballX = canvas.width - paddleWidth - ballSize;
  }

  // Score
  if (ballX < 0) {
    rightScore++;
    resetBall();
  }
  if (ballX > canvas.width - ballSize) {
    leftScore++;
    resetBall();
  }
}

function draw() {
  ctx.clearRect(0, 0, canvas.width, canvas.height);
  drawRect(0, leftY, paddleWidth, paddleHeight, "#0ff");
  drawRect(canvas.width - paddleWidth, rightY, paddleWidth, paddleHeight, "#ff0");
  drawBall(ballX, ballY, ballSize, "#fff");
  drawText(leftScore, canvas.width / 4, 40);
  drawText(rightScore, canvas.width * 3 / 4, 40);
}

function gameLoop() {
  update();
  draw();
  requestAnimationFrame(gameLoop);
}

resetBall();
gameLoop();